export const checkCredentials = (email, password) => {
  return email === "boss@example.com" && password === "supersecure123";
};
